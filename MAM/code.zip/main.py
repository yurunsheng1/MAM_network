"""
The main scripts. 
"""
import configparser
import sys
import Vec
import utils
import CNN_GAP_MAM
import CNN_fine_turn
if __name__ == '__main__':

    config = configparser.ConfigParser()
    config.read(sys.argv[1])

    if utils.str2bool(config['Pipeline']['Vec']):
        print("Starting to learn a distributed representation of amino acids...")
        Vec.run(config['Vec'], config['FilesDirectories'])

    if utils.str2bool(config['Pipeline']['train']):
        print("Start training")
        CNN_GAP_MAM.train(config['Hyper-Parameter for MAM'], config['FilesDirectories'])
    if utils.str2bool(config['Pipeline']['evaluate']):
        print("Performing prediction on the test set...")
        CNN_GAP_MAM.evaluate(config['FilesDirectories'])

    if utils.str2bool(config['Pipeline']['inference']):
        print("Performing inference on the test set...")
        CNN_GAP_MAM.inference_and_generation(config['FilesDirectories'])
		
		
    if utils.str2bool(config['Pipeline']['fine_train']):
        print("Starting the fine turn training of HLA-CNN...")
        CNN_fine_turn.train(config['Hyper-Parameter for Fine-tune'], config['FilesDirectories'])
		
    if utils.str2bool(config['Pipeline']['fine_evaluate']):
        print("Performing fine turn inference on the test set...")
        CNN_fine_turn.evaluate(config['FilesDirectories'])
		
    if utils.str2bool(config['Pipeline']['fine_inference']):
        print("Performing fine turn test on the test set...")
        CNN_fine_turn.inference_and_generation(config['FilesDirectories'])