"""
This file contains helpful miscellaneous functions.
It is from https://github.com/uci-cbcl/HLA-bind.
"""


def str2bool(word):
    if word.lower() == 'true':
        return True
    else:
        return False
